# Urban Textiles Website

Urban Textiles is a responsive static website for a fabric and sewing studio based in Durban, South Africa. The website promotes the business, showcases products, displays workshop information, and allows customers to book classes or contact the store.

## Project Purpose
This site was created to:
- showcase the business and brand identity
- advertise textile products and sewing accessories
- provide workshop and class information
- allow online booking for classes
- enable customers to contact the business

## Pages Included
- Home
- About Us
- Shop Online
- Workshops and Classes
- Book a Class
- Contact and Location

## Technologies Used
- HTML5
- CSS3
- JavaScript
- External OpenStreetMap embed for the location map

## Features Included
- Responsive navigation
- Product search on the shop page
- Add-to-cart interaction
- Image gallery lightbox
- Class booking form validation
- Contact form validation
- SEO meta tags for title, description, and keywords

## How to View the Website
Open the `index.html` file in a browser to view the site locally.

## Author
Urban Textiles
