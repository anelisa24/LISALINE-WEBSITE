const cartCount = document.getElementById('cart-count');
const cartItemsList = document.getElementById('cart-items');
const cartItemTotal = document.getElementById('cart-item-total');
const cartTotalEl = document.getElementById('cart-total');
const cartPanel = document.getElementById('cart-panel');
const cartToggle = document.getElementById('cart-toggle');
const closeCartButton = document.getElementById('close-cart');
const checkoutButton = document.querySelector('.checkout-btn');

let cart = [];

const formatCurrency = (amount) => `R${amount.toFixed(2)}`;

const updateCartDisplay = () => {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => sum + item.quantity * item.price, 0);

    if (cartCount) cartCount.textContent = totalItems;
    if (cartItemTotal) cartItemTotal.textContent = totalItems;
    if (cartTotalEl) cartTotalEl.textContent = formatCurrency(totalPrice);

    if (!cartItemsList) return;

    if (cart.length === 0) {
        cartItemsList.innerHTML = '<li class="empty-cart">Your cart is empty.</li>';
        return;
    }

    cartItemsList.innerHTML = cart.map(item => `
        <li class="cart-item">
            <div class="cart-item-info">
                <strong>${item.name}</strong>
                <span>${item.quantity} x ${formatCurrency(item.price)}</span>
            </div>
            <div class="cart-controls">
                <div class="quantity-box">
                    <button type="button" class="qty-btn" data-action="decrease" data-name="${item.name}">−</button>
                    <span>${item.quantity}</span>
                    <button type="button" class="qty-btn" data-action="increase" data-name="${item.name}">+</button>
                </div>
                <button type="button" class="remove-btn" data-name="${item.name}">Remove</button>
            </div>
            <span class="item-total">${formatCurrency(item.quantity * item.price)}</span>
        </li>
    `).join('');

    document.querySelectorAll('.qty-btn').forEach((button) => {
        button.addEventListener('click', () => {
            const name = button.dataset.name;
            const action = button.dataset.action;
            const found = cart.find(item => item.name === name);

            if (!found) return;

            if (action === 'increase') {
                found.quantity += 1;
            } else {
                found.quantity -= 1;
                if (found.quantity <= 0) {
                    cart = cart.filter(item => item.name !== name);
                }
            }

            updateCartDisplay();
        });
    });

    document.querySelectorAll('.remove-btn').forEach((button) => {
        button.addEventListener('click', () => {
            const name = button.dataset.name;
            cart = cart.filter(item => item.name !== name);
            updateCartDisplay();
        });
    });
};

const addToCart = (name, price) => {
    const existingItem = cart.find(item => item.name === name);

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ name, price, quantity: 1 });
    }

    updateCartDisplay();
    if (cartPanel) cartPanel.classList.add('open');
};

const bindAddToCart = () => {
    document.querySelectorAll('.add-to-cart').forEach((button) => {
        button.addEventListener('click', () => {
            const card = button.closest('.product-card');
            const name = card?.querySelector('h3')?.textContent?.trim() || 'Product';
            const price = Number(card?.dataset.price || 0);
            addToCart(name, price);
        });
    });
};

const setupCartToggle = () => {
    if (cartToggle) {
        cartToggle.addEventListener('click', () => {
            if (cartPanel) cartPanel.classList.toggle('open');
        });

        cartToggle.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                if (cartPanel) cartPanel.classList.toggle('open');
            }
        });
    }

    if (closeCartButton && cartPanel) {
        closeCartButton.addEventListener('click', () => cartPanel.classList.remove('open'));
    }
};

const setupLightbox = () => {
    const lightbox = document.getElementById('lightbox');
    const lightboxImage = document.getElementById('lightbox-image');
    const closeButton = document.querySelector('.lightbox-close');

    document.querySelectorAll('.lightbox-trigger').forEach((image) => {
        image.addEventListener('click', () => {
            if (!lightbox || !lightboxImage) return;
            lightboxImage.src = image.src;
            lightbox.classList.add('active');
        });
    });

    if (closeButton && lightbox) {
        closeButton.addEventListener('click', () => lightbox.classList.remove('active'));
        lightbox.addEventListener('click', (event) => {
            if (event.target === lightbox) lightbox.classList.remove('active');
        });
    }
};

const setupProductSearch = () => {
    const searchInput = document.getElementById('product-search');
    const cards = document.querySelectorAll('.product-card');

    if (!searchInput || !cards.length) return;

    searchInput.addEventListener('input', (event) => {
        const query = event.target.value.trim().toLowerCase();

        cards.forEach((card) => {
            const content = (card.dataset.name + ' ' + card.dataset.type).toLowerCase();
            card.style.display = content.includes(query) ? 'block' : 'none';
        });
    });
};

const validateField = (input) => {
    const value = input.value.trim();
    if (!value) {
        return `${input.name || 'This field'} is required.`;
    }

    if (input.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        return 'Please enter a valid email address.';
    }

    if (input.type === 'tel' && value.length < 10) {
        return 'Please enter a valid phone number.';
    }

    return '';
};

const setupFormValidation = () => {
    const forms = document.querySelectorAll('form[data-form]');

    forms.forEach((form) => {
        form.addEventListener('submit', (event) => {
            event.preventDefault();
            const messageBox = form.querySelector('.form-message');
            let firstError = null;

            form.querySelectorAll('input, select, textarea').forEach((field) => {
                const error = validateField(field);
                field.setCustomValidity(error);
                if (error && !firstError) {
                    firstError = field;
                }
            });

            if (firstError) {
                firstError.focus();
                if (messageBox) {
                    messageBox.textContent = 'Please complete all required fields correctly.';
                    messageBox.className = 'form-message error';
                }
                return;
            }

            const formName = form.dataset.form === 'booking' ? 'class booking' : 'message';
            if (messageBox) {
                messageBox.textContent = `Your ${formName} has been successfully submitted.`;
                messageBox.className = 'form-message success';
            }
            form.reset();
        });
    });
};

const setupCheckout = () => {
    if (!checkoutButton) return;

    checkoutButton.addEventListener('click', () => {
        if (cart.length === 0) {
            alert('Your cart is empty. Add an item before checking out.');
            return;
        }

        alert('Checkout successful! Your order is ready for confirmation.');
        cart = [];
        updateCartDisplay();
    });
};

bindAddToCart();
setupCartToggle();
setupCheckout();
setupLightbox();
setupProductSearch();
setupFormValidation();
updateCartDisplay();
