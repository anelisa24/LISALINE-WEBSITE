# Changelog

## Version 1.0 - Part 3 Update
- Added SEO meta title, description, and keywords to all website pages.
- Improved navigation structure for stronger site usability.
- Added interactive product search to the shop page.
- Added add-to-cart functionality with live cart count.
- Added image lightbox gallery for product and content images.
- Added JavaScript validation for booking and contact forms.
- Added a live map iframe to the contact page.
- Improved form labels and accessibility for users.
- Created a project README with project details and overview.

## Version 0.5 - Initial Website Structure
- Created the initial static website layout.
- Added a homepage, about page, shop, workshops, booking, and contact pages.
- Added styling and basic content for all pages.
- Included product cards, class schedule, and contact details.
